package br.com.isidrocorp.dashcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashCardApplicationTests {

	@Test
	void contextLoads() {
	}

}
